ZX Spectrum Sound Chip Emulator source code.

Program "AY-3-8910/12 Emulator"
Version 2.9 beta 25 for Windows and Linux
Author is Sergey Vladimirovich Bulba
(c)1999-2018 S.V.Bulba

Send any comments to Sergey Bulba <svbulba@gmail.com>
Ay_Emul home page is http://bulba.untergrund.net/

You can use this source code freely, only do references to author (Sergey Bulba).

Compilers used for corresponding versions:
Win32: Lazarus 1.8.0, FPC 3.0.4, SVN revision: 56594, i386-win32-win32/win64
Win64: Lazarus 1.8.0, FPC 3.0.4, SVN revision: 56594, x86_64-win64-win32/win64
Lin32: Lazarus 1.8.0, FPC 3.0.4, SVN revision: 56607, i386-linux-gtk2
Lin64: Lazarus 1.8.0, FPC 3.0.4, SVN revision: 56622:56623, x86_64-linux-gtk2
